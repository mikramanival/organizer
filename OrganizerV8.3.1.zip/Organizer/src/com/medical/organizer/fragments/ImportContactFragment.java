package com.medical.organizer.fragments;

import java.util.ArrayList;
import java.util.UUID;

import android.app.ListFragment;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts.Data;
import android.provider.ContactsContract.RawContacts;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import com.medical.organizer.R;
import com.medical.organizer.utilities.Contacts;
import com.medical.organizer.utilities.Helper;

public class ImportContactFragment extends ListFragment{
	private static UUID CONTACT_ID;
	private Helper help = new Helper(getActivity());
	//private ContentResolver cr = getContentResolver();
	private String contact;
	private String number;
	public String[] Contacts = {};
	 public int[] to = {};

	
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setHasOptionsMenu(true);
			/*try{
				Import();
			}catch (Exception e){
				Log.d("log","no entries");
					Toast.makeText(getActivity(), "No contacts on Phone", Toast.LENGTH_LONG).show();
			}*/
	 }
	 @Override
		public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
			inflater.inflate(R.menu.contact_list_fragment, menu);
			super.onCreateOptionsMenu(menu, inflater);
		}

	 @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		 View v = inflater.inflate(R.layout.import_contacts_layout_fragment_list, null);
		 Button save = (Button) v.findViewById(R.id.save);
      	 save.setOnClickListener(new OnClickListener() {
				//CONTINUE HERE!
				public void onClick(View s) {
					ListView v = getListView();
					int count = v.getCheckedItemCount();
					long[] ids = v.getCheckItemIds();
					ArrayList<Contacts> cList = new ArrayList<Contacts>();
						
						for(int i = 0; i < ids.length; i++)
						{
							Contacts c = getContactDetails(ids[i]);
							cList.add(c);
								
						}
						Log.d("CheckItemCount","===============================");
							for(Contacts item: cList)
							{
								 Log.d("CheckItemCount","Name: "+item.getName());
								 Log.d("CheckItemCount","Number: "+item.getNum());
							}
						Log.d("CheckItemCount","===============================");
					
					 Log.d("CheckItemCount","SAVED!");
					 Log.d("CheckItemCount","Number of Contacts checked: "+count);
					 Log.d("CheckItemCount"," ");
				}
			});
		return v;
	}
	 
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState); 
		
		Cursor c = getContacts();
		getActivity().startManagingCursor(c);
		ListAdapter adapter = new SimpleCursorAdapter(getActivity(), 
							android.R.layout.simple_list_item_multiple_choice, 
							c, 
							Contacts = new String[] { ContactsContract.Contacts.DISPLAY_NAME },
				            to = new int[] { android.R.id.text1 });
         setListAdapter(adapter);
         ListView v = getListView();
         v.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
         v.setItemsCanFocus(false);
         
         
	}
	
	private Contacts getContactDetails(long id) {
	    Contacts con = null;
	    Cursor contactCursor = null;
	    contactCursor = queryContactsDetails(id);
	    if(contactCursor != null)
	    {
	    	if(contactCursor.getCount() != 0)
	    	{	
	    		contactCursor.moveToFirst();
	    		while(!contactCursor.isAfterLast())
	    		{
	    			con = new Contacts();
	    			con.setName(contactCursor.getString(contactCursor.getColumnIndex(Phone.DISPLAY_NAME)));
	    			con.setNum(contactCursor.getString(contactCursor.getColumnIndex(Phone.NUMBER)));
	    			contactCursor.moveToNext();
	    		}
	    	}
	    }

	    return con;
	}


	private Cursor queryContactsDetails(long contactId) {
	    ContentResolver cr = getActivity().getContentResolver();
	    Uri baseUri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI,
	            contactId);
	    Uri dataUri = Uri.withAppendedPath(baseUri,
	            ContactsContract.Contacts.Data.CONTENT_DIRECTORY);

	    Cursor c = cr.query(dataUri, 
				    		new String[] { Phone._ID, Phone.NUMBER,
				            Phone.IS_SUPER_PRIMARY, RawContacts.ACCOUNT_TYPE, Phone.TYPE,
				            Phone.LABEL , Phone.DISPLAY_NAME},
				            Data.MIMETYPE + "=?",
				            new String[] { Phone.CONTENT_ITEM_TYPE },
				            null);
	    if (c != null && c.moveToFirst()) {
	        return c;
	    }
	    return null;
	}

	
	private Cursor getContacts() {
        // Run query
        Uri uri = ContactsContract.Contacts.CONTENT_URI;
        String[] projection = new String[] { ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME };
        String selection = ContactsContract.Contacts.HAS_PHONE_NUMBER + " = '"
                + ("1") + "'";
        String[] selectionArgs = null;
        String sortOrder = ContactsContract.Contacts.DISPLAY_NAME
                + " COLLATE LOCALIZED ASC";
        
        return getActivity().getContentResolver().query(uri, projection, selection, selectionArgs,
                sortOrder);
    }
	
	/*public void VeiwEditImportedContacts( final Contacts contact){
		final Dialog d = new Dialog(getActivity());
		d.setTitle("Update Entry");
		d.setContentView(R.layout.input_contacts_entry);
			TextView header = (TextView) d.findViewById(R.id.header);
			header.setVisibility(TextView.GONE);
			final TextView Name = (TextView) d.findViewById(R.id.name_ca);
			final TextView address = (TextView) d.findViewById(R.id.address_ca);
			final TextView num = (TextView) d.findViewById(R.id.number_ca);
			final TextView specs = (TextView) d.findViewById(R.id.spec_ca);
			
			final Button save = (Button) d.findViewById(R.id.add_edit_con_info);
			final Button cancel = (Button) d.findViewById(R.id.cancel_ca);
			
			save.setEnabled(false);
			
			save.setText("UPDATE");
			Name.setText(contact.getName());
			address.setText(contact.getAddr());
			num.setText(contact.getNum());
			specs.setText(contact.getSpec());
			
			Name.addTextChangedListener((TextWatcher) this);
			address.addTextChangedListener((TextWatcher) this);
			specs.addTextChangedListener((TextWatcher) this);
			num.addTextChangedListener((TextWatcher) this);
			
			save.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					AlertDialog.Builder build = new AlertDialog.Builder(getActivity());
					build.setMessage("Are all edits Correct?");	
			    	build.setCancelable(false);
					build.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							Contacts con = contact;
							con.setName(Name.getText().toString());
							con.setAddr(address.getText().toString());
							con.setNum(num.getText().toString());
							con.setSpec(specs.getText().toString());
							help.update(con, Helper.NORMAL);
							Toast.makeText(getActivity(), "Updated!", Toast.LENGTH_SHORT).show();
							 Import();
							d.cancel();
						}
					});
					build.setNegativeButton("No", new DialogInterface.OnClickListener() {
						
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});
					
					AlertDialog alert = build.create();
					alert.show();
				}
			});
			cancel.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					d.cancel();
				}
			});
		d.show();
		
	}*/
	
	/*public void Import(){

		/*ArrayList<Contacts> list = new ArrayList<Contacts>();
		Cursor cur = getActivity().getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
			cur.moveToFirst();
			int n = cur.getCount();
			Log.d("Val","ss"+n);

		/*while(!cur.isAfterLast()) {
			Contacts con = new Contacts();
			   String contactId = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID)); 
			   String hasPhone = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)); 
			   Log.d("con","ss"+contactId);
			   Log.d("HP",""+hasPhone);
		
			      Cursor phones = getActivity().getContentResolver().query( ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ contactId, null, null); 
			      Log.d("phone",""+phones.getCount());
			      phones.moveToFirst();
			     
			      while (!phones.isAfterLast()) { 
			    	  
			    	  String name =  phones.getString(phones.getColumnIndex( ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));   
			    	  Log.d("name",""+name);
			    	  con.setName(name);
			        
			    	  String phoneNumber = phones.getString(phones.getColumnIndex( ContactsContract.CommonDataKinds.Phone.NUMBER));                 
			          Log.d("num",""+phoneNumber);
			          con.setNum(phoneNumber);
			          phones.moveToNext();
			      } 
			      phones.close(); 
		       list.add(con);
			   cur.moveToNext();
		}
		cur.close();*/
		/*Cursor c = getContacts();
		getActivity().startManagingCursor(c);
		ListAdapter adapter = new SimpleCursorAdapter(getActivity(), 
							android.R.layout.simple_list_item_multiple_choice, 
							c, 
							Contacts = new String[] { ContactsContract.Contacts.DISPLAY_NAME },
				            to = new int[] { android.R.id.text1 });
         setListAdapter(adapter);
         ListView v = getListView();
         v.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
         v.setItemsCanFocus(false);
         
         /*registerForContextMenu(getListView());
			getListView().setOnItemClickListener(new OnItemClickListener() {

				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					Contacts contact = (Contacts) getListAdapter().getItem(arg2);
					VeiwEditImportedContacts(contact);
				}
			});
	}*/
	
}
